import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:project_final/module/events/view/SplashScreen.dart';
import 'package:project_final/module/events/view/event_cart_screen.dart';
import 'package:project_final/module/events/view/event_list_screen.dart';

class AppRoutes {
  static const splash = '/splash';
  static const events = '/events';
  static const cartScreen = '/cart';

  static final pages = [
    GetPage(
      name: splash,
      page: () => SplashScreen(),
    ),
    GetPage(
      name: events,
      page: () => EventListScreen(),
    ),
    GetPage(
      name: cartScreen,
      page: () => EventCartScreen(),
    ),
  ];
}
