import 'package:flutter/material.dart';

class DarkThemeColors {
  // PRIMARY
  static const Color primaryColor = Color(0xFFFFFFFF);

  // SECONDARY
  static const Color accentColor = Color(0xFF121212);

  // Appbar
  static const Color appbarColor = accentColor;

  // SCAFFOLD
  static const Color scaffoldBackgroundColor = accentColor;

  static const Color backgroundColor = Color(0xff1A1A1A);
  static const Color cardColor = Color(0xff262626);

  static const Color dividerColor = Color(0xff262626);

  // ICONS
  static const Color appBarIconsColor = primaryColor;
  static const Color iconColor = primaryColor;
  static const Color unSelectedIconColor = Color(0xFFCECECE);

  // TEXT
  static const Color bodyTextColor = primaryColor;
  static const Color textAccentColor = Color(0xff007AFF);
  static const Color hintAccentColor = Color(0xff999999);
}
