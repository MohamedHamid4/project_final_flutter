import 'package:flutter/material.dart';

class LightThemeColors {
  // PRIMARY
  static const Color primaryColor = Color(0xFF121212);

  // SECONDARY
  static const Color accentColor = Color(0xFFFFFFFF);

  // Appbar
  static const Color appbarColor = accentColor;

  // SCAFFOLD
  static const Color scaffoldBackgroundColor = accentColor;

  static const Color backgroundColor = Color(0xffF8F8F8);
  static const Color cardColor = Color(0xffF2F2F2);

  static const Color dividerColor = Color(0xffEEEEEE);

  // ICONS
  static const Color appBarIconsColor = primaryColor;
  static const Color iconColor = primaryColor;
  static const Color unSelectedIconColor = Color(0xFFCECECE);

  // TEXT
  static const Color bodyTextColor = primaryColor;
  static const Color textAccentColor = Color(0xff007AFF);
  static const Color hintAccentColor = Color(0xff999999);
}
