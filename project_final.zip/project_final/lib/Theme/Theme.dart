import 'package:flutter/material.dart';
import 'DarkThemeColors.dart';
import 'LightThemeColors.dart';

class MyTheme {
  static getThemeData({required bool isLight}) {
    // اذا كان المتغير متشابه في كل الدوال يمكننا ان نقوم بتعريفه وتمريره على كل الدوال مرة واحدة
    final fontW = FontWeight.w400;
    // بالنسبة للون مرة واحدة ايضا يتم تعريفه وتمريره مرة واحده بدل من كتابة الكود اكثر من مرة
    final Color color = isLight?LightThemeColors.primaryColor:DarkThemeColors.primaryColor;

    return ThemeData(
       textTheme: TextTheme(
         bodyMedium: TextStyle(
           fontSize: 15,
           //fontWeight: FontWeight.w400,
           fontWeight: fontW,
           //color: Colors.black
           color: color
         ),

         bodyLarge: TextStyle(
           fontSize: 20,
           fontWeight: fontW,
           color: color
         ),

         bodySmall: TextStyle(
             fontSize: 10,
             fontWeight: fontW,
             color: color
         ),

       ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(
            isLight
                ? LightThemeColors.primaryColor
                : DarkThemeColors.primaryColor,
          ),
          foregroundColor: MaterialStateProperty.all<Color>(
            isLight
                ? LightThemeColors.accentColor
                : DarkThemeColors.accentColor,
          ),
          shape: MaterialStateProperty.all<OutlinedBorder>(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
            textStyle: MaterialStateProperty.all<TextStyle>(
              TextStyle(fontSize: 20, fontWeight: FontWeight.bold)
            ),
          minimumSize: MaterialStateProperty.all<Size>(
            Size(120, 50)
          ),
          padding: MaterialStateProperty.all<EdgeInsets>(
            EdgeInsets.symmetric(vertical: 12, horizontal:12)
          ),
        ),
      ),
    );
  }
}
