import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:project_final/helper/MyShared.dart';

class MyTheme {
  MyTheme._();

  static changeTheme() async {
    final isLight = MyShared.getThemeMode();

    await MyShared.setThemeMode(!isLight);

    Get.changeThemeMode(isLight ? ThemeMode.light : ThemeMode.dark);
  }
}
