class EventModel {
  final String imageUrl;
  final double price;
  final String title;
  final String address;
  final double rating;
  final bool isActive;

  EventModel({
    required this.imageUrl,
    required this.price,
    required this.title,
    required this.address,
    required this.rating,
    required this.isActive,
  });
}
