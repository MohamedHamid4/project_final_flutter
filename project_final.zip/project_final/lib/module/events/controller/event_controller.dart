import 'package:get/get.dart';
import '../model/event_model.dart';

class EventController extends GetxController {
  final RxList<EventModel> events = <EventModel>[
    EventModel(
      imageUrl: 'assets/images/event1.png',
      price: 500.0,
      title: 'Music Concert',
      address: 'Riyadh, Marash Tower',
      rating: 4.5,
      isActive: true,
    ),
    EventModel(
      imageUrl: 'assets/images/event2.png',
      price: 300.0,
      title: 'Art Exhibition',
      address: 'Jeddah, Art Center',
      rating: 4.2,
      isActive: false,
    ),
    EventModel(
      imageUrl: 'assets/images/event3.png',
      price: 600.0,
      title: 'Food Festival',
      address: 'Riyadh, Food Hall',
      rating: 4.7,
      isActive: true,
    ),
    EventModel(
      imageUrl: 'assets/images/event1.png',
      price: 500.0,
      title: 'Music Concert',
      address: 'Riyadh, Marash Tower',
      rating: 4.5,
      isActive: true,
    ),
    EventModel(
      imageUrl: 'assets/images/event2.png',
      price: 300.0,
      title: 'Art Exhibition',
      address: 'Jeddah, Art Center',
      rating: 4.2,
      isActive: false,
    ),
    EventModel(
      imageUrl: 'assets/images/event3.png',
      price: 600.0,
      title: 'Food Festival',
      address: 'Riyadh, Food Hall',
      rating: 4.7,
      isActive: true,
    ),
  ].obs;

  final RxList<EventModel> cart = <EventModel>[].obs;

  final RxString couponCode = ''.obs;

  final RxDouble discountValue = 0.0.obs;

  void addToCart(EventModel event) {
    if (!cart.contains(event) && event.isActive) {
      cart.add(event);
    }
  }

  void removeFromCart(EventModel event) {
    cart.remove(event);
  }

  void clearAll() {
    cart.clear();
  }

  void editEventInCart(EventModel oldEvent, String newTitle) {
    final index = cart.indexOf(oldEvent);
    if (index != -1) {
      final updatedEvent = EventModel(
        imageUrl: oldEvent.imageUrl,
        price: oldEvent.price,
        title: newTitle,
        address: oldEvent.address,
        rating: oldEvent.rating,
        isActive: oldEvent.isActive,
      );
      cart[index] = updatedEvent;
    }
  }

  double get totalPrice {
    double sum = 0;
    for (var item in cart) {
      sum += item.price;
    }
    return sum;
  }

  double get totalPriceAfterDiscount => totalPrice - discountValue.value;

  void applyCoupon() {
    if (couponCode.value == '123A') {
      discountValue.value = totalPrice * 0.10;
    } else if (couponCode.value == '123B') {
      discountValue.value = totalPrice * 0.20;
    } else if (couponCode.value == '123C') {
      discountValue.value = totalPrice * 0.30;
    } else {
      discountValue.value = 0.0;
    }
  }
}
