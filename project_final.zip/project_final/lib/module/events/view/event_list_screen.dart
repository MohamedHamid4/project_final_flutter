import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:project_final/translations/LocalizationService.dart';
import '../controller/event_controller.dart';
import '../../../route/app_route.dart';

class EventListScreen extends GetView<EventController> {
  final RxBool isDark = false.obs;
  final RxString selectedLang = 'en'.obs;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Events'),
        actions: [
          IconButton(
            icon: Icon(Icons.settings),
            onPressed: () {
              Get.defaultDialog(
                title: 'Settings',
                titleStyle: TextStyle(fontWeight: FontWeight.bold),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('Language'),
                    SizedBox(height: 8),
                    Obx(() {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ChoiceChip(
                            label: Text('EN'),
                            selected: selectedLang.value == 'en',
                            onSelected: (value) {
                              if (value) {
                                selectedLang.value = 'en';
                                 LocalizationService.defualtLanguage;
                              }
                            },
                          ),
                          SizedBox(width: 8),
                          ChoiceChip(
                            label: Text('AR'),
                            selected: selectedLang.value == 'ar',
                            onSelected: (value) {
                              if (value) {
                                selectedLang.value = 'ar';
                                 LocalizationService.supportedLanguage;
                              }
                            },
                          ),
                        ],
                      );
                    }),
                    SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Theme Dark'),
                        Obx(() {
                          return Switch(
                            value: isDark.value,
                            onChanged: (value) {
                              isDark.value = value;
                              ///// Theme
                            },
                          );
                        }),
                      ],
                    ),
                  ],
                ),
                textConfirm: 'Done',
                confirmTextColor: Colors.white,
                onConfirm: () {
                  Get.back();
                },
              );
            },
          ),
        ],
      ),
      body: Obx(() {
        return ListView.builder(
          itemCount: controller.events.length,
          itemBuilder: (context, index) {
            final event = controller.events[index];
            return Card(
              margin: EdgeInsets.all(8),
              child: Padding(
                padding: EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image.asset(
                      event.imageUrl,
                      height: 150,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                    SizedBox(height: 8),
                    Text('${event.price} SR',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    SizedBox(height: 4),
                    Text(event.title),
                    SizedBox(height: 4),
                    Text(event.address),
                    SizedBox(height: 4),
                    Row(
                      children: [
                        Text('${event.rating}'),
                        Icon(Icons.star, color: Colors.amber, size: 18),
                      ],
                    ),
                    SizedBox(height: 8),
                    Align(
                      alignment: Alignment.centerRight,
                      child: ElevatedButton(
                        onPressed: () {
                          controller.addToCart(event);
                        },
                        child: Text('ADD TO CARD'),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      }),
      bottomNavigationBar: Container(
        padding: EdgeInsets.all(8),
        child: ElevatedButton(
          onPressed: () {
            Get.offAllNamed(AppRoutes.cartScreen);
          },
          child: Text('GO TO CARD'),
        ),
      ),
    );
  }
}
