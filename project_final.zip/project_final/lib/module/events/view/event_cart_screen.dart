import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/event_controller.dart';

class EventCartScreen extends GetView<EventController> {
  final TextEditingController couponController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Obx(() => Text('Your Cart (${controller.cart.length})')),
        actions: [
          IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Get.offAllNamed('/events');
            },
          ),
          TextButton(
            onPressed: () {
              controller.clearAll();
            },
            child: Text(
              'Clear All',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),

      body: Obx(() {
        if (controller.cart.isEmpty) {
          return Center(child: Text('The List is Empty'));
        }
        return SingleChildScrollView(
          child: Column(
            children: [
              ListView.builder(
                itemCount: controller.cart.length,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  final event = controller.cart[index];
                  return Card(
                    margin: EdgeInsets.all(8),
                    child: ListTile(
                      leading: Image.asset(
                        event.imageUrl,
                        width: 60,
                        fit: BoxFit.cover,
                      ),
                      title: Text(event.title),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${event.price} SR'),
                          SizedBox(height: 4),
                          Text(event.address),
                        ],
                      ),
                      trailing: SizedBox(
                        width: 120,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            IconButton(
                              icon: Icon(Icons.edit),
                              onPressed: () {
                                TextEditingController editController = TextEditingController(text: event.title);
                                Get.defaultDialog(
                                  title: 'Edit Title',
                                  content: Column(
                                    children: [
                                      TextField(
                                        controller: editController,
                                        decoration: InputDecoration(
                                          hintText: 'Enter new title',
                                        ),
                                      ),
                                    ],
                                  ),
                                  confirm: ElevatedButton(
                                    onPressed: () {
                                      controller.editEventInCart(event, editController.text);
                                      Get.back();
                                    },
                                    child: Text('Save'),
                                  ),
                                  cancel: ElevatedButton(
                                    onPressed: () => Get.back(),
                                    child: Text('Cancel'),
                                  ),
                                );
                              },
                            ),
                            IconButton(
                              icon: Icon(Icons.delete),
                              onPressed: () {
                                controller.removeFromCart(event);
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
              SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: couponController,
                        decoration: InputDecoration(
                          labelText: 'Have Coupon?',
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (value) {
                          controller.couponCode.value = value;
                        },
                      ),
                    ),
                    SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: () {
                        controller.applyCoupon();
                        FocusScope.of(context).unfocus();

                        if (controller.discountValue.value > 0.0) {
                          Get.defaultDialog(
                            title: '',
                            content: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.check_circle, color: Colors.green, size: 48),
                                SizedBox(height: 8),
                                Text('Discount Successfully'),
                              ],
                            ),
                            confirm: ElevatedButton(
                              onPressed: () => Get.back(),
                              child: Text('DONE'),
                            ),
                          );
                        } else {
                          Get.defaultDialog(
                            title: '',
                            content: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.error, color: Colors.red, size: 48),
                                SizedBox(height: 8),
                                Text('active not is Coupone'),
                              ],
                            ),
                            confirm: ElevatedButton(
                              onPressed: () => Get.back(),
                              child: Text('OK'),
                            ),
                          );
                        }
                      },
                      child: Text('CHECK'),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Obx(() {
                  final original = controller.totalPrice;
                  final afterDiscount = controller.totalPriceAfterDiscount;
                  if (controller.discountValue.value == 0.0) {
                    return Text(
                      'Total Order Value\n${original.toStringAsFixed(2)} SR',
                      textAlign: TextAlign.center,
                    );
                  } else {
                    return Column(
                      children: [
                        Text(
                          'Total Order Value\n${afterDiscount.toStringAsFixed(2)} SR',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 4),
                        Text(
                          '${original.toStringAsFixed(2)} SR',
                          style: TextStyle(
                            decoration: TextDecoration.lineThrough,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    );
                  }
                }),
              ),
            ],
          ),
        );
      }),
    );
  }
}
