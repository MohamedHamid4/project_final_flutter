class Strings {
  static final String login = "Sign In";
  static final String SignUp = "Sign Up";
  static final String email = "email";
  static final String passward = "passward";
}
