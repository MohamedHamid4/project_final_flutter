import 'package:project_final/translations/stringsKey.dart';

final Map<String, String> enUS = {
  Strings.login: "Sign In",
  Strings.SignUp: "Sign Up",
  Strings.email: "email",
  Strings.passward: "passward"
};
