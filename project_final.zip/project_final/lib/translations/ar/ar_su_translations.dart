import 'package:project_final/translations/stringsKey.dart';

final Map<String, String> arSU = {
  Strings.login: "تسجيل الدخول",
  Strings.SignUp: "تسجيل حساب جديد",
  Strings.email: "البريد الالكتروني",
  Strings.passward: "كلمة المرور",
};
