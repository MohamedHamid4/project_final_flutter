import 'dart:ui';
import 'package:get/get.dart';
import 'package:project_final/helper/MyShared.dart';
import 'ar/ar_su_translations.dart';
import 'en/en_us_translations.dart';

class LocalizationService extends Translations {
  static LocalizationService? _instance;

  static LocalizationService getInstance() {
    _instance ??= LocalizationService();
    return _instance!;
  }

  static Map<String, Locale> supportedLanguage = {
    'en': Locale('en', 'US'),
    'ar': Locale('ar', 'SU'),
  };

  static Locale defualtLanguage = supportedLanguage['ar']!;

  @override
  // TODO: implement keys
  Map<String, Map<String, String>> get keys => {
        'en_US': enUS,
        'ar_SU': arSU,
      };

  static updateLanguage() async {
    String langCode = MyShared.getLocal();
    if (langCode == 'ar') {
      langCode = "en";
    } else if (langCode == "en") {
      langCode = "ar ";
    } else {
      langCode = "ar";
    }
    await MyShared.setLocal(langCode);
    await Get.updateLocale(supportedLanguage[langCode]!);
  }
}
