import 'package:shared_preferences/shared_preferences.dart';

class MyShared {
  static late SharedPreferences prefs;
  static final String themeMode = "themeMode";
  static final String _local = "local";

  static init() async {
    prefs = await SharedPreferences.getInstance();
  }

  static setThemeMode(bool isLight) async {
    await prefs.setBool(themeMode, isLight);
  }

  static getThemeMode() {
    return prefs.getBool(themeMode) ?? true;
  }

  static setLocal(String local) async {
    await prefs.setString(_local, local);
  }

  static getLocal() {
    return prefs.getString(_local ) ?? "ar";
  }
}
