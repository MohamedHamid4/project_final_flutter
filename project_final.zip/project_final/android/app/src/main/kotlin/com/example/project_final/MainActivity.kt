package com.example.project_final

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
